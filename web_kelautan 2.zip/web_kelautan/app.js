const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { Pool } = require('pg');
const authRoutes = require('./routes/auth');
const kapalRoutes = require('./routes/kapal');

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());

// Database connection pool
const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});

app.locals.db = pool;

// Root endpoint
app.get('/', (req, res) => {
  res.send('Welcome to Sistem Informasi Kelautan API');
});

// Routes
app.use('/auth', authRoutes);
app.use('/kapal', kapalRoutes);

// Start server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
